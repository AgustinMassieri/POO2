const FiguraGeometrica = require('./FiguraGeometrica');

function Pentagono(id){

    if(!(this instanceof Pentagono)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new Pentagono(id);
    }
    
    FiguraGeometrica.call(this, id, 'Pentagono', 5, '2D');
    
    this.lado = 10;
    this.apotema = 10;

    this.setLado = function(lado){
        
        if ( lado <= 0 ){

            console.log("No se puede asignar un lado <= 0!");
        }
        else{
            
            this.lado = lado;
        }
    }

    this.setApotema = function(apotema){

        if ( apotema <= 0 ){

            console.log("No se puede asignar un apotema <= 0!");
        }
        else{
            
            this.apotema = apotema;
        }
    }
}
   
Pentagono.prototype = Object.create(FiguraGeometrica.prototype); 
Pentagono.prototype.constructor = Pentagono;

module.exports = Pentagono;

Pentagono.prototype.calcularPerimetro = function (){

    return 5 * this.lado;
}

Pentagono.prototype.calcularArea = function (){
    
    return this.calcularPerimetro() * this.apotema;
}