const Circulo = require('./Circulo');

function Esfera(id){
    
    if(!(this instanceof Esfera)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new Esfera(id);
    }

    Circulo.call(this, id, 'Esfera', 0, '3D');
    
}
   
Esfera.prototype = Object.create(Circulo.prototype); 
Esfera.prototype.constructor = Esfera;

Esfera.prototype.description = function(){
    var mensaje =  "\n> Soy una Figura Geometrica llamada: Esfera y tengo: " + this.numLados + " lados! Mi id es: " + this.getId() + " y mi dimesion es: 3D.";
    
    return mensaje;
}

Esfera.prototype.calcularArea = function(){

    return 4 * Math.PI * Math.pow(this.radio,2);
}

Esfera.prototype.calcularVolumen = function(){

    return (4/3) * Math.PI * Math.pow(this.radio,3);
}

module.exports = Esfera;