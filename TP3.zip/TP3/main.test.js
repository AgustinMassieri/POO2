const FigurasGeometricasFactory = require('./FigurasGeometricasFactory');

//--- TEST TRIANGULO ---

test("El area de un triangulo de base 4 y altura 3 es 6", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const triangulo = factory.createFiguraGeometrica(3, '2D');
    triangulo.setBase(4);
    triangulo.setAltura(3);

    expect(triangulo.calcularArea()).toBe(6);
});

test("El area de un triangulo de base 2 y altura 2 es 2", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const triangulo = factory.createFiguraGeometrica(3, '2D');
    triangulo.setBase(2);
    triangulo.setAltura(2);
    
    expect(triangulo.calcularArea()).toBe(2);
});

//--- TEST ESFERA ---

test("El volumen de una esfera de radio 1 es 36 * PI", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const esfera = factory.createFiguraGeometrica(0, '3D');
    esfera.setRadio(1);

    expect(esfera.calcularVolumen()).toBe((4/3) * Math.PI);
});

test("El volumen de una esfera de radio 10 es (4000/3) * PI", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const esfera = factory.createFiguraGeometrica(0, '3D');
    esfera.setRadio(10);

    expect(esfera.calcularVolumen()).toBe((4000/3) * Math.PI);
});

test("Cambiar el radio de una esfera a -10 da error", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const esfera = factory.createFiguraGeometrica(0, '3D');
    
    expect(esfera.setRadio(-10)).toBeUndefined();
});

//--- TEST CUADRADO ---

test("El perimetro de un cuadrado de lado 4 es 16", () => {
    
    const factory = new FigurasGeometricasFactory(); 
    const cuadrado = factory.createFiguraGeometrica(4, '2D');
    cuadrado.setLado(4); 

    expect(cuadrado.calcularPerimetro()).toBe(16);
});

test("El perimetro de un cuadrado de lado 6 es 24", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const cuadrado = factory.createFiguraGeometrica(4, '2D');
    cuadrado.setLado(6);

    expect(cuadrado.calcularPerimetro()).toBe(24);
});

test("Cambiar el lado de un cuadrado a -3 da error", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const cuadrado = factory.createFiguraGeometrica(4, '2D');

    expect(cuadrado.setLado(-3)).toBeUndefined();
});

//--- TEST CUBO ---

test("El volumen de un cubo de lado 2 es 8", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const cubo = factory.createFiguraGeometrica(4, '3D');
    cubo.setLado(2);

    expect(cubo.calcularVolumen()).toBe(8);
});
//--- TEST PENTAGONO ---
test("El area de un pentagono de lado 2 ,apotema 4 200", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const pentagono = factory.createFiguraGeometrica(5, '3D');
    pentagono.setLado(2);
    pentagono.setApotema(4);

    expect(pentagono.calcularArea()).toBe(40);
});

//--- TEST PRISMA ---

test("El volumen de un prisma pentagonal de lado 2 ,apotema 4 y altura 5 es 200", () => {
   
    const factory = new FigurasGeometricasFactory(); 
    const prismaPentagonal = factory.createFiguraGeometrica(5, '3D');
    prismaPentagonal.setLado(2);
    prismaPentagonal.setApotema(4);
    prismaPentagonal.setAltura(5);

    expect(prismaPentagonal.calcularVolumen()).toBe(200);
});

