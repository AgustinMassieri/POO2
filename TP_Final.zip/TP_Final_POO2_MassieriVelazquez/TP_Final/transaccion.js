/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

function Transaccion(id, vehiculo, combustible, cantidadARecargar){


    var id = id;

    this.getId = function(){ //Getter del atributo privado Id
        return id;
    }
    
    this.IdVehiculo = vehiculo.getId();
    this.nombreVehiculo = vehiculo.nombre;
    this.combustible = combustible;
    this.cantidadARecargar = cantidadARecargar;
    this.monto = combustible.precioPorLitro * cantidadARecargar;

}

Transaccion.prototype.description = function(){

    console.log("\n", this.getId(), "\t\t", this.IdVehiculo, "\t\t", this.nombreVehiculo, "\t\t ", this.combustible.nombre ,"\t\t ", this.cantidadARecargar,"\t\t\t ",this.monto.toFixed(0));
}

module.exports = Transaccion;