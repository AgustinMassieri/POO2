/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

/*
    -- Metodologia TDD: --
    (Es muy importante el orden!)
    1.- Escribir los test
    2.- Desarrollar las funciones para poder cumplir los test

*/
//VEHICULOS FACTORY-----
// ---Importamos los archivos necesarios
const VehiculosFactory = require("./vehiculosFactory");

test("La cantidad de ruedas de la moto debe ser 2", () => {
   
    const fabricaDeVehiculos = new VehiculosFactory();
    var moto = fabricaDeVehiculos.createVehiculo(2);

    expect(moto.cantidadDeRuedas).toBe(2);
});

test("La moto debe aceptar Combustible tipo Regular o Premium", () => {
   
    const fabricaDeVehiculos = new VehiculosFactory();
    var moto = fabricaDeVehiculos.createVehiculo(2);

    expect(moto.tipoDeCombustible).toEqual(expect.arrayContaining(["Regular","Premium"]));
});

test("La cantidad de ruedas del auto debe ser 4", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    var auto = fabricaDeVehiculos.createVehiculo(4);

    expect(auto.cantidadDeRuedas).toBe(4);
});

test("El auto debe aceptar Combustible tipo Regular o Premium", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    var auto = fabricaDeVehiculos.createVehiculo(4);

    expect(auto.tipoDeCombustible).toEqual(expect.arrayContaining(["Regular", "Premium"]));
});
test("No se puede crear un vehiculo de 3 ruedas", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    
    expect(fabricaDeVehiculos.createVehiculo(3)).toBeUndefined();
});

test("El camion debe aceptar Combustible tipo Diesel", () => {
   
    const fabricaDeVehiculos = new VehiculosFactory();
    var camion = fabricaDeVehiculos.createVehiculo(6);

    expect(camion.tipoDeCombustible).toEqual(expect.arrayContaining(["Diesel"]));
});

test("El camion no debe aceptar Combustible Regular", () => {
   
    const fabricaDeVehiculos = new VehiculosFactory();
    var camion = fabricaDeVehiculos.createVehiculo(6);

    expect(camion.tipoDeCombustible).not.toEqual(expect.arrayContaining(["Regular"]));
});

test("La cantidad de ruedas del camion debe ser 6", () => {

    const fabricaDeVehiculos = new VehiculosFactory();
    var camion = fabricaDeVehiculos.createVehiculo(6);

    expect(camion.cantidadDeRuedas).toBe(6);
});

test("Los Vehiculos siempre tienen el Combustible lleno al maximo cuando recien se instancian", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    var camion = fabricaDeVehiculos.createVehiculo(6);
   
    expect(camion.combustibleDisponible).toEqual(camion.capacidadCombustible);
});

test("Los Vehiculos siempre tienen el Combustible lleno al maximo cuando recien se instancian", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    var auto = fabricaDeVehiculos.createVehiculo(4);
   
    expect(auto.combustibleDisponible).toEqual(auto.capacidadCombustible);
});

test("Los Vehiculos siempre tienen el Combustible lleno al maximo cuando recien se instancian", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    var moto = fabricaDeVehiculos.createVehiculo(2);
   
    expect(moto.combustibleDisponible).toEqual(moto.capacidadCombustible);
});

test("El ID de los Vehiculos es privado por lo que no deberiamos poder acceder a el sin usar un Getter", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    var moto = fabricaDeVehiculos.createVehiculo(2);
   
    expect(moto.id).toBeUndefined();
});

test("El ID de los Vehiculos es privado por lo que no deberiamos poder acceder a el sin usar un Getter", () => {
    
    const fabricaDeVehiculos = new VehiculosFactory();
    var auto = fabricaDeVehiculos.createVehiculo(4);
   
    expect(auto.id).toBeUndefined();
});