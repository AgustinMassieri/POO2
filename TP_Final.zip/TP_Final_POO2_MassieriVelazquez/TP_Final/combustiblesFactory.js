/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const Regular = require('./Regular');
const Premium = require('./Premium');
const Diesel = require('./Diesel');


function CombustiblesFactory(){ //Factory Method
    
    this.contador_id = 0;
}

CombustiblesFactory.prototype.description = function(){

    var mensaje = "\n--> Soy la CombustiblesFactory";
    return mensaje;
}

CombustiblesFactory.prototype.createCombustible = function(nombre){

    if( nombre == "Regular" ) {
        this.contador_id += 1;
        return new Regular(this.contador_id);
    }

    else if( nombre == "Premium" ) {
        this.contador_id += 1;
        return new Premium(this.contador_id);
    }

    else if( nombre == "Diesel" ) {
        this.contador_id += 1;
        return new Diesel(this.contador_id);
    }

    console.log("\n> No se encontro ese combustible en la CombustiblesFactory!");

}

module.exports = CombustiblesFactory;