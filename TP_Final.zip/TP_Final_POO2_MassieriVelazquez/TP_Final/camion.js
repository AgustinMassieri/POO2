/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const Vehiculo = require("./vehiculo");

function Camion(id) {

    Vehiculo.call(this, id, "Camion", ["Diesel"]);

    this.combustibleDisponible = 100;
    this.capacidadCombustible = 100;
    this.cantidadDeRuedas = 6;
    
}

Camion.prototype = Object.create(Vehiculo.prototype); 
Camion.prototype.constructor = Camion;

Camion.prototype.description = function(){
    var mensaje = "\n> Soy un Camion de " + this.cantidadDeRuedas + " ruedas. Mi Id es: " + this.getId() + ". El estado de mi tanque de combustible es: " + this.combustibleDisponible + "/" + this.capacidadCombustible + ". Mis tipos de combustible son: " + this.tipoDeCombustible;

    return mensaje;
}

module.exports = Camion;