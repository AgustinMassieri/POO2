/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

function Vehiculo(id, nombre, listaDeCombustible) {

    if(!(this instanceof Vehiculo)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar el vehiculo
        return new Vehiculo(id, nombre);
    }

    var id = id;
    this.nombre = nombre;

    this.getId = function(){
        return id;
    }

    this.combustibleDisponible = 0;
    this.capacidadCombustible = 0;
    this.tipoDeCombustible = listaDeCombustible;
}

Vehiculo.prototype.description = function(){
    var mensaje =  "\n> Soy un Vehiculo llamado: " + this.nombre + " .Mi id es: " + this.getId() + ".";
    
    return mensaje;
}

Vehiculo.prototype.buscarCombustible = function(combustible){

    return this.tipoDeCombustible.find( item => item == combustible.nombre);
}

Vehiculo.prototype.obtenerCantidaARecagrar = function(){

    return this.capacidadCombustible - this.combustibleDisponible;
}

Vehiculo.prototype.aumentarCantidadDisponible = function(cantidadARecargar){
    
    this.combustibleDisponible += cantidadARecargar;
}


module.exports = Vehiculo;