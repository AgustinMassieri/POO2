/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

/*
    -- Metodologia TDD: --
    (Es muy importante el orden!)
    1.- Escribir los test
    2.- Desarrollar las funciones para poder cumplir los test

*/
//VEHICULOS FACTORY-----
// ---Importamos los archivos necesarios
const CombustiblesFactory = require("./combustiblesFactory");
const VehiculosFactory = require("./vehiculosFactory"); //algunos si o si lo necesitan para poder funcionar conrrectamente
const Gasolinera = require("./gasolinera");
const Stock = require("./stock");

test("No se puede crear el Combustible 'Infinia'", () => {
   
    const fabricaDeCombustibles = new CombustiblesFactory();
    
    expect(fabricaDeCombustibles.createCombustible("Infinia")).toBeUndefined();
});

test("No se puede cargar Combustible si el tanque del Vehiculo esta lleno", () => { // TAMBIEN USA VEHICULOS FACTORY
    
    const fabricaDeCombustibles = new CombustiblesFactory();
    var diesel = fabricaDeCombustibles.createCombustible("Diesel");

    const fabricaDeVehiculos = new VehiculosFactory();
    var camion = fabricaDeVehiculos.createVehiculo(6);
   

    Stock.agregarCombustible(diesel);

    var ypf = new Gasolinera(1, "YPF", Stock);

    expect(ypf.cargarCombustible(diesel, camion)).toBeUndefined();
});

test("Si recargo el Combustible del Vehiculo, este debe llenarse al maximo", () => {// TAMBIEN USA VEHICULOS FACTORY
    
    const fabricaDeCombustibles = new CombustiblesFactory();
    var diesel = fabricaDeCombustibles.createCombustible("Diesel");

    const fabricaDeVehiculos = new VehiculosFactory();
    var camion = fabricaDeVehiculos.createVehiculo(6);
    camion.combustibleDisponible = 0;
   
 
    Stock.agregarCombustible(diesel);

    var ypf = new Gasolinera(1, "YPF", Stock);
    ypf.cargarCombustible(diesel, camion)

    expect(camion.combustibleDisponible).toEqual(camion.capacidadCombustible);
});

test("Los almacenes de Combustible siempre estan llenos cuando recien se instancian", () => {
    
    const fabricaDeCombustibles = new CombustiblesFactory();
    var diesel = fabricaDeCombustibles.createCombustible("Diesel");
   
    expect(diesel.cantidadDisponible).toEqual(diesel.cantidadAlmacenamiento);
});

test("Los almacenes de Combustible siempre estan llenos cuando recien se instancian", () => {
    
    const fabricaDeCombustibles = new CombustiblesFactory();
    var regular = fabricaDeCombustibles.createCombustible("Regular");
   
    expect(regular.cantidadDisponible).toEqual(regular.cantidadAlmacenamiento);
});

test("El ID de los Combutibles es privado por lo que no deberiamos poder acceder a el sin usar un Getter", () => {
    
    const fabricaDeCombustibles = new CombustiblesFactory();
    var regular = fabricaDeCombustibles.createCombustible("Regular");
   
    expect(regular.id).toBeUndefined();
});

test("El ID de los Combutibles es privado por lo que no deberiamos poder acceder a el sin usar un Getter", () => {
    
    const fabricaDeCombustibles = new CombustiblesFactory();
    var diesel = fabricaDeCombustibles.createCombustible("Diesel");
   
    expect(diesel.id).toBeUndefined();
});
