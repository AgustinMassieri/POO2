
/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

+ No abusar del if(..)!

+ No abusar de las listas, debemos dejar que los objetos resuelvan
    .. ciertos asuntos. No podemos recorrer todo el tiempo listas   
    .. usando los indices de las mismas.

+ TDD --> No ponerlos todos juntos! 

          Puede que nos interese testear solo una parte!
         
          Primero se escriben los test, luego vemos como programamos
          .. la funcion para que se cumpla el test

+ Nombres claros tanto para las variables como para las funciones!

+ No repetir codigo, usar funciones!

+ Las funciones deben tener un proposito claro y conciso, no debemos
  .. hacer funciones muy largas!

+ Ayudarse con los patrones de diseño para una mejor programación!
  --> Factory Method (Combustibles y Vehiculos)
  --> Module Pattern (Stock)

+ Comentar el codigo en caso de que haga falta para que otra persona
  .. pueda comprender lo que hace cada linea

+ Separar en distintos archivos el programa!

+ Detectar casos de herencia!

+ Ciertos atributos deben ser privados! 
  No todo debe ser visible para todos
