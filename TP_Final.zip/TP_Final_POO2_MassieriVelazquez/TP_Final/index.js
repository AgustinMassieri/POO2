
/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

const CombustiblesFactory = require("./combustiblesFactory");
const Gasolinera = require("./gasolinera");
const Stock = require("./stock");
const VehiculosFactory = require("./vehiculosFactory");

var express = require('express')
var app = express()
var port = 3000

var fabricaDeVehiculos = new VehiculosFactory();
var listaVehiculos = [];
var i = 0;
var cantRuedas = [2,4,6];

while (i < 50 ){
    var ruedaRandom = cantRuedas[Math.floor(Math.random() *cantRuedas.length)];
    listaVehiculos.push(fabricaDeVehiculos.createVehiculo(ruedaRandom));
    i += 1;
}

var fabricaDeCombustibles = new CombustiblesFactory();
var regular = fabricaDeCombustibles.createCombustible("Regular");
var premium = fabricaDeCombustibles.createCombustible("Premium");
var diesel = fabricaDeCombustibles.createCombustible("Diesel");

Stock.agregarCombustible(regular);
Stock.agregarCombustible(premium);
Stock.agregarCombustible(diesel);

var ypf = new Gasolinera(1, "YPF", Stock);


app.listen(port, () => {
    console.log("Server Running in port ", port);
})

app.get("/getTransacciones", (req, res) => {

    res.send(ypf.cargarCombustibleDeUnaLista(listaVehiculos))
})

app.get("/getTotal", (req, res) => {

    var lista = ypf.cargarCombustibleDeUnaLista(listaVehiculos);

    res.send(ypf.calcularGananciaTotal(lista))
})
